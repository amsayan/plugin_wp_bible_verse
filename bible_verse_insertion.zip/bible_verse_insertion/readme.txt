=== Bible-verse-insertion pour Wordpress ===
Auteur: Rakotoarimalala Tsinjo Tony
Tags: bible, Louis segond, Malagasy
Tested up to: 4.8.2
Requires PHP: 5.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Date: mai 2020

Aide à l'insertion de versets Bibliques version Louis segond et la version malgache.


== Description ==


= À quoi sert ce plugin ? =

Ce plugin permet d'insérer facilement des versets de la Bible dans votre blog. Dans la langue malgache ou français version Louis Segond.

= Comment se servir du plugin =

Une fois installé, il vous suffit d'aller sur la page d'édition d'un post. Vous verrez apparaitre un nouveau bouton avec le logo "Croix" dans la barre d'outil de l'éditeur. Cliquez dessus pour ouvrir la boite de dialogue Bible-verse.

Recherche par référence:

Si vous connaissez la référence du verset à insérer, il suffit de soit la taper dans le champ de saisie soit d'utiliser les menu déroulants. 


= Quelles sont les version disponibles ? =

* Louis Segond
* Malagasy

= Base de données
Le plugin embarque deux tables dans votre base de données : La version malagasy et la version Louis Segond. 

= Hors ligne
Puisque la base de données est embarquée dans le plugin alors le plugin peut s'uiliser en hors ligne

= Première ativation lente
Le plugin intègre deux tables, et lors de son activation, il insère ces deux tables qui ont chacun preque 30.000 enregistrements. L'activation prend quelque temps pour la premère fois.

= Inspiré de TopBible
Ce plugin est inspiré du plugin TopBible 